/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sprint3Java.Old;

public class Blogs {

    String titol;
    String contingut;

    // setter per a establir el titol
    public void setTitol(String titol) {
        this.titol = titol;
    }

    // getter per a mostrar el titol
    public String getTitol() {
        return titol;
    }

    // setter per a establir el titol
    public void setContingut(String post) {
        this.contingut = post;
    }

    // getter per a mostrar el contingut
    public String getContingut() {
        return contingut;
    }
}
