
package Sprint3Java.Old;

/**
 *
 * @author alumne
 */
public class Article {

    String titol;
    String contingut;

    // metodes setter per a establir el titol de l'article
    public void setTitol(String titol) {
        this.titol = titol;
    }

    // metodes getter per a mostrar el titol de l'article
    public String getTitol() {
        return titol;

    }

    // metodes setter per a establir el contingut de l'article
    public void setContingut(String article) {
        this.contingut = article;
    }

    // metodes getter per a mostrar el contingut de l'article
    public String getContingut() {
        return contingut;

    }

}
