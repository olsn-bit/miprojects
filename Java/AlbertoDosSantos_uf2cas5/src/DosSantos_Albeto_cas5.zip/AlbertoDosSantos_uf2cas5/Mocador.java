package AlbertoDosSantos_uf2cas5;
public class Mocador {
    private String color;
    public Mocador(String color){
        this.color = color;
    }
    public String getColor(){
        return this.color;
    }
}
