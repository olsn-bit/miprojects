package AlbertoDosSantos_uf2cas5;
public class Test {
    public static void main(String[] args) {
         Mocador[] barret1 = new Mocador[3];
         Barret.crearBarret(barret1);
         Barret.imprimirBarret(barret1);

    }
}
